import React, { useState } from 'react';

const AdminPanel = ({ setTips }: { setTips: any }) => {
  const [form, setForm] = useState({ title: '', description: '', odds: '', date: '' });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTips((prev: any[]) => [...prev, form]);
    setForm({ title: '', description: '', odds: '', date: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-xl mx-auto space-y-4">
      <input name="title" placeholder="Title" value={form.title} onChange={handleChange} className="w-full p-2 rounded" required />
      <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} className="w-full p-2 rounded" required />
      <input name="odds" placeholder="Odds" value={form.odds} onChange={handleChange} className="w-full p-2 rounded" required />
      <input name="date" placeholder="Date" value={form.date} onChange={handleChange} className="w-full p-2 rounded" required />
      <button type="submit" className="bg-white text-[#0A1128] px-4 py-2 rounded">Add Tip</button>
    </form>
  );
};

export default AdminPanel;
