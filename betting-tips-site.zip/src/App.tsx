import React, { useState } from 'react';
import TipCard from './components/TipCard';
import tipsData from './data/tips';
import AdminPanel from './pages/AdminPanel';

const App = () => {
  const [tips, setTips] = useState(tipsData);
  const [isAdmin, setIsAdmin] = useState(false);

  return (
    <div className="min-h-screen p-4 bg-[#0A1128] text-white">
      <header className="flex justify-between items-center border-b border-gray-700 pb-4 mb-4">
        <h1 className="text-3xl font-bold">Betting Tips</h1>
        <button
          onClick={() => setIsAdmin(!isAdmin)}
          className="px-4 py-2 bg-white text-[#0A1128] rounded-xl font-semibold"
        >
          {isAdmin ? 'View Tips' : 'Admin Panel'}
        </button>
      </header>
      {isAdmin ? (
        <AdminPanel setTips={setTips} />
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {tips.map((tip, index) => (
            <TipCard key={index} {...tip} />
          ))}
        </div>
      )}
    </div>
  );
};

export default App;
