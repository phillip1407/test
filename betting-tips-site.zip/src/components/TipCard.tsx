import React from 'react';

type Tip = {
  title: string;
  description: string;
  odds: string;
  date: string;
};

const TipCard = ({ title, description, odds, date }: Tip) => (
  <div className="bg-white text-[#0A1128] p-4 rounded-xl shadow-lg">
    <h2 className="text-xl font-bold mb-2">{title}</h2>
    <p className="mb-2">{description}</p>
    <p className="text-sm">Odds: <strong>{odds}</strong></p>
    <p className="text-xs text-gray-700">Date: {date}</p>
  </div>
);

export default TipCard;
