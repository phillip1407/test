export default [
  {
    title: "Team A vs Team B",
    description: "We predict a strong win for Team A based on recent performance.",
    odds: "2.5",
    date: "2025-06-24",
  },
  {
    title: "Player X to Score",
    description: "Player X has scored in the last 3 games, looking sharp.",
    odds: "3.0",
    date: "2025-06-25",
  }
];
